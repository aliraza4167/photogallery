

<?php $__env->startSection('content'); ?>
    <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4"><div class="chartjs-size-monitor"><div class="chartjs-size-monitor-expand"><div class=""></div></div><div class="chartjs-size-monitor-shrink"><div class=""></div></div></div>
        <br />
        <h2>Add a photo:</h2>
        <br />
        <form method="POST" action="/photos" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <p><?php echo e($error); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            <div class="row">
                <div class="col-sm">
                    <div class="mb-3">
                        <label for="title" class="form-label">Photo Title</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="">

                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div id="titleerror" class="invalid-feedback">
                                <p><?php echo e($errors->first('title')); ?></p>
                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                        
                    </div>
                    <div class="mb-3">
                        <label for="image" class="form-label">Choose a photo from your computer</label>
                        <input class="form-control" type="file" id="image" name="image">
                    </div>
                    <div class="mb-3">
                        <label for="caption" class="form-label">Photo Caption</label>
                        <input type="text" class="form-control" id="caption" name="caption" placeholder="">
                    </div>
                    <div class="mb-3">
                        <label for="description" class="form-label">Photo Description</label>
                        <textarea class="form-control" id="description" name="description" rows="3"></textarea>
                    </div>
                    <div class="mb-3">
                        <input type="submit" class="form-control" id="submit" value="Save" placeholder="">
                    </div>
                </div>
                <div class="col-sm">
    
                </div>
                <div class="col-sm">
                    
                </div>
            </div>
        </form>
        
        
       
    </main>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\AliPersonalDataAndFiles\ProgrammingProjects\Laravel\bakery\resources\views/photos/create.blade.php ENDPATH**/ ?>